# DDFM
Deep Dynamic Factor Models

This package provides replication codes for the Monte Carlo excercise of the following paper.

Title: 'Deep Dnamic Factor Models'


Link to the paper: https://arxiv.org/abs/2007.11887.
